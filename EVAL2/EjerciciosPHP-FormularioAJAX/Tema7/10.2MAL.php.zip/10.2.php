<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

    <form action="10.2.php" method="POST">

       <?php

            echo "<input type='text' name='nombre'>";
            echo "<input type='submit'>";
            echo "</form>";

            if($_POST["nombre"]!=""){
  
                $name="micookie";
                $value=$_POST["nombre"]; # Podría ser una cadena de texto
                $expires=time()+3000; # 60 segundos después del momento actual
                $path="/";
                $domain="";
                $secure=false;
                $HttpOnly=true;
               
                # Es preciso asegurarse de llamar a setcookie() antes de enviar
                # ninguna otra salida al navegador
                setcookie ($name,$value,$expires,$path,$domain,$secure,$HttpeOnly);
               
                $servidor = "localhost";
                $username = "miusuario";
                $password = "mipassword";
                $basedatos = "bdprueba";
                
                # Crear conexión
                $conn = mysqli_connect($servidor, $username, $password, $basedatos);
                
                if (!$conn) {
                    die("Conexi&ocacuten fallida: " . mysqli_connect_error());
                }else{echo "Conexi&oacuten con &eacutexito <br><br>";}
    
                $idSumado=0;
                $nombre = mysqli_query($conn, "SELECT nombre FROM ejercicio102;");

                if(!$nombre){
                    echo "selector fallido<br>";
                }  else{
                    echo "selector con exito<br>";
                }

                $saludarOK=false;
                //echo "lista de nombres:<br>";
                while ($fila = mysqli_fetch_array($nombre)){ 

                    //echo $fila[0]."<br>";

                    if($fila[0]==$_POST['nombre']){
                        $saludarOK=true;break;
                    }
                }

                if($saludarOK==false){
                $nombreInput = $_POST['nombre'];
                $consulta = mysqli_query($conn, "INSERT INTO ejercicio102(nombre) VALUES ('$nombreInput')");
        
                if(!$consulta){
                    echo "<br>id nombre insertado  error<br>";
                }  else{
                    echo "<br>id nombre insertado corectamente<br>";
                }
        
            }else{
                echo "<br>NOMBRE registrado:Saludos ". $_POST['nombre'];
            }
                
                
               // header("Location: 10.2.php");






        }
    
    
    ?>


     
  </body>

    </body>
</html>